document.addEventListener("DOMContentLoaded", () => {
  const $  = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];

  const LABELS = { aberto: "Em aberto", andamento: "Em andamento", finalizado: "Finalizado" };
  const cards = $$(".ticket");

  /* ---------- Modais ---------- */
  $$("[data-open]").forEach(btn =>
    btn.addEventListener("click", () => document.getElementById(btn.dataset.open).showModal())
  );
  $$("dialog").forEach(dlg => {
    $$("[data-close]", dlg).forEach(b => b.addEventListener("click", () => dlg.close()));
    // clicar fora da caixa fecha
    dlg.addEventListener("click", e => { if (e.target === dlg) dlg.close(); });
  });

  /* ---------- Criar chamado ---------- */
  const campoData = $("#campo-data");
  if (campoData) campoData.value = new Date().toLocaleDateString("sv-SE"); // AAAA-MM-DD (hoje)

  const texto = $("textarea[name=descricao]"), contador = $("#contador");
  if (texto && contador) texto.addEventListener("input", () => (contador.textContent = texto.value.length));

  /* ---------- Detalhes / ações ---------- */
  const det = $("#modal-detalhes");
  const blocoCancelar = $("#bloco-cancelar"), confirmar = $("#confirmar"), btnCancelar = $("#btn-cancelar");

  cards.forEach(card => {
    $("[data-details]", card).addEventListener("click", () => {
      const status = card.dataset.status;
      const campo = f => $(`[data-f=${f}]`, card).textContent.trim();

      $("#det-titulo").textContent = $(".ticket__title", card).childNodes[0].textContent.trim();
      $("#det-item").textContent = $(".ticket__title span", card).textContent.replace("· ", "");
      $("#det-data").textContent = campo("data");
      $("#det-setor").textContent = campo("setor");
      $("#det-etiqueta").textContent = campo("etiqueta");
      $("#det-desc").innerHTML = $("[data-desc-full]", card).innerHTML;

      const badge = $("#det-badge");
      badge.className = `badge badge--${status}`;
      badge.innerHTML = `<i class="dot dot--${status}"></i>${LABELS[status] || status}`;

      $$(".js-id", det).forEach(i => (i.value = card.dataset.id));

      const sel = $("#det-novo-status");
      if (sel) sel.value = status === "finalizado" ? "finalizado" : "andamento";

      // Cancelamento só é permitido enquanto estiver "Em aberto"
      blocoCancelar.hidden = status !== "aberto";
      confirmar.hidden = true;
      btnCancelar.hidden = false;

      det.showModal();
    });
  });

  btnCancelar.addEventListener("click", () => { btnCancelar.hidden = true; confirmar.hidden = false; });
  $("#btn-nao").addEventListener("click", () => { confirmar.hidden = true; btnCancelar.hidden = false; });

  /* ---------- Filtros (status + data + setor) ---------- */
  const chips = $$(".chip");
  const fData = $("#filtro-data"), fSetor = $("#filtro-setor"), limpar = $("#limpar-filtros");
  const vazio = $("#vazio"), vazioTitulo = $("#vazio-titulo"), vazioTexto = $("#vazio-texto");
  let statusAtivo = "todos";

  const norm = s => (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  function contar() {
    const c = { todos: cards.length, aberto: 0, andamento: 0, finalizado: 0 };
    cards.forEach(card => c[card.dataset.status] !== undefined && c[card.dataset.status]++);
    Object.entries(c).forEach(([k, v]) => { const el = $(`[data-count=${k}]`); if (el) el.textContent = v; });
  }

  function filtrar() {
    const data = fData ? fData.value : "";
    const setor = fSetor ? norm(fSetor.value.trim()) : "";
    let visiveis = 0;

    cards.forEach(card => {
      const ok =
        (statusAtivo === "todos" || card.dataset.status === statusAtivo) &&
        (!data || card.dataset.date === data) &&
        (!setor || norm(card.dataset.setor).includes(setor));
      card.hidden = !ok;
      if (ok) visiveis++;
    });

    vazio.hidden = visiveis > 0;
    if (visiveis === 0) {
      const temFiltro = cards.length > 0;
      vazioTitulo.textContent = temFiltro ? "Nada encontrado" : "Nenhum chamado por aqui";
      vazioTexto.textContent = temFiltro
        ? "Tente mudar ou limpar os filtros."
        : "Quando você abrir um chamado, ele aparece nesta lista.";
    }
  }

  chips.forEach(chip => chip.addEventListener("click", () => {
    statusAtivo = chip.dataset.status;
    chips.forEach(c => c.classList.toggle("is-active", c === chip));
    filtrar();
  }));
  if (fData) fData.addEventListener("input", filtrar);
  if (fSetor) fSetor.addEventListener("input", filtrar);
  if (limpar) limpar.addEventListener("click", () => { fData.value = ""; fSetor.value = ""; filtrar(); });

  contar();
  filtrar();
});