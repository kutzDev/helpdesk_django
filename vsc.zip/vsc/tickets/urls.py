from django.urls import path
from . import views

urlpatterns = [
    path('chamados/', views.ticket_list, name='ticket_list'),
]