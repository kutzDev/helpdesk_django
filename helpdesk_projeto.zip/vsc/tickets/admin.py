from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import Chamado, Usuario


@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    # Acrescenta o campo "permissão" à tela de edição e de criação de usuário.
    fieldsets = UserAdmin.fieldsets + (('Permissão do HelpDesk', {'fields': ('permissao',)}),)
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Permissão do HelpDesk', {'fields': ('permissao',)}),
    )
    list_display = ('username', 'first_name', 'last_name', 'permissao', 'is_active')
    list_filter = ('permissao', 'is_active')


@admin.register(Chamado)
class ChamadoAdmin(admin.ModelAdmin):
    list_display = ('id', 'titulo', 'usuario', 'data', 'status')
    list_filter = ('status', 'data')
    search_fields = ('titulo', 'subtitulo', 'usuario__username')
    readonly_fields = ('data',)
