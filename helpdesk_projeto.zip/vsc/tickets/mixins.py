from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.core.exceptions import PermissionDenied


class AdminRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Libera a view apenas para administradores.

    Não logado -> vai para a tela de login.
    Logado mas comum -> erro 403 (acesso proibido).
    """

    def test_func(self):
        return self.request.user.eh_admin

    def handle_no_permission(self):
        if self.request.user.is_authenticated:
            raise PermissionDenied
        return super().handle_no_permission()
