from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
    path('login/', auth_views.LoginView.as_view(
        template_name='tickets/login.html',
        redirect_authenticated_user=True,
    ), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    path('chamados/', views.ChamadoListView.as_view(), name='ticket_list'),
    path('chamados/novo/', views.ChamadoCreateView.as_view(), name='ticket_create'),
    path('chamados/status/', views.ChamadoStatusView.as_view(), name='ticket_status'),
    path('chamados/cancelar/', views.ChamadoCancelView.as_view(), name='ticket_cancel'),
]
