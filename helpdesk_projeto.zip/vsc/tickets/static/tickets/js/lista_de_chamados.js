document.addEventListener("DOMContentLoaded", () => {
  const $  = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];

  const LABELS = { aberto: "Em aberto", andamento: "Em andamento", finalizado: "Finalizado" };
  const cards = $$(".ticket");

  /* ---------- Modais ---------- */
  $$("[data-open]").forEach(btn =>
    btn.addEventListener("click", () => document.getElementById(btn.dataset.open).showModal())
  );
  $$("dialog").forEach(dlg => {
    $$("[data-close]", dlg).forEach(b => b.addEventListener("click", () => dlg.close()));
    // clicar fora da caixa fecha
    dlg.addEventListener("click", e => { if (e.target === dlg) dlg.close(); });
  });

  /* ---------- Criar chamado ---------- */
  // Data automática (só exibição). Quem grava a data de verdade é o back-end.
  const autoData = $("#auto-data");
  if (autoData) autoData.textContent = new Date().toLocaleDateString("pt-BR");

  const texto = $("textarea[name=descricao]"), contador = $("#contador");
  if (texto && contador) texto.addEventListener("input", () => (contador.textContent = texto.value.length));

  /* ---------- Detalhes / ações ---------- */
  const det = $("#modal-detalhes");
  const blocoCancelar = $("#bloco-cancelar"), confirmar = $("#confirmar"), btnCancelar = $("#btn-cancelar");

  cards.forEach(card => {
    $("[data-details]", card).addEventListener("click", () => {
      const status = card.dataset.status;
      const campo = f => $(`[data-f=${f}]`, card).textContent.trim();

      $("#det-titulo").textContent = `Chamado #${card.dataset.id}`;
      $("#det-titulo-chamado").textContent = campo("titulo");
      $("#det-subtitulo").textContent = campo("subtitulo");
      $("#det-usuario").textContent = campo("usuario");
      $("#det-data").textContent = campo("data");
      $("#det-desc").innerHTML = $("[data-desc-full]", card).innerHTML;

      const badge = $("#det-badge");
      badge.className = `badge badge--${status}`;
      badge.innerHTML = `<i class="dot dot--${status}"></i>${LABELS[status] || status}`;

      $$(".js-id", det).forEach(i => (i.value = card.dataset.id));

      const sel = $("#det-novo-status");
      if (sel) sel.value = status === "finalizado" ? "finalizado" : "andamento";

      // Cancelamento só é permitido enquanto estiver "Em aberto"
      blocoCancelar.hidden = status !== "aberto";
      confirmar.hidden = true;
      btnCancelar.hidden = false;

      det.showModal();
    });
  });

  btnCancelar.addEventListener("click", () => { btnCancelar.hidden = true; confirmar.hidden = false; });
  $("#btn-nao").addEventListener("click", () => { confirmar.hidden = true; btnCancelar.hidden = false; });

  /* ---------- Filtros (status + data + busca) ---------- */
  const chips = $$(".chip");
  const fData = $("#filtro-data"), fBusca = $("#filtro-busca"), limpar = $("#limpar-filtros");
  const vazio = $("#vazio"), vazioTitulo = $("#vazio-titulo"), vazioTexto = $("#vazio-texto");
  let statusAtivo = "todos";

  const norm = s => (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  function contar() {
    const c = { todos: cards.length, aberto: 0, andamento: 0, finalizado: 0 };
    cards.forEach(card => c[card.dataset.status] !== undefined && c[card.dataset.status]++);
    Object.entries(c).forEach(([k, v]) => { const el = $(`[data-count=${k}]`); if (el) el.textContent = v; });
  }

  function filtrar() {
    const data = fData ? fData.value : "";
    const busca = fBusca ? norm(fBusca.value.trim()) : "";
    let visiveis = 0;

    cards.forEach(card => {
      const ok =
        (statusAtivo === "todos" || card.dataset.status === statusAtivo) &&
        (!data || card.dataset.date === data) &&
        (!busca || norm(card.dataset.busca).includes(busca));
      card.hidden = !ok;
      if (ok) visiveis++;
    });

    vazio.hidden = visiveis > 0;
    if (visiveis === 0) {
      const temFiltro = cards.length > 0;
      vazioTitulo.textContent = temFiltro ? "Nada encontrado" : "Nenhum chamado por aqui";
      vazioTexto.textContent = temFiltro
        ? "Tente mudar ou limpar os filtros."
        : "Quando você abrir um chamado, ele aparece nesta lista.";
    }
  }

  chips.forEach(chip => chip.addEventListener("click", () => {
    statusAtivo = chip.dataset.status;
    chips.forEach(c => c.classList.toggle("is-active", c === chip));
    filtrar();
  }));
  if (fData) fData.addEventListener("input", filtrar);
  if (fBusca) fBusca.addEventListener("input", filtrar);
  if (limpar) limpar.addEventListener("click", () => { fData.value = ""; fBusca.value = ""; filtrar(); });

  // Mensagens do sistema somem sozinhas depois de alguns segundos
  $$(".toast").forEach((t, i) => setTimeout(() => {
    t.classList.add("is-hiding");
    setTimeout(() => t.remove(), 450);
  }, 4000 + i * 600));

  contar();
  filtrar();
});
