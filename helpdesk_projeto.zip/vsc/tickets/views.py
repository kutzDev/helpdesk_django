from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseNotAllowed
from django.shortcuts import get_object_or_404, redirect
from django.views import View
from django.views.generic import ListView

from .forms import ChamadoForm
from .mixins import AdminRequiredMixin
from .models import Chamado


class ChamadoBaseMixin(LoginRequiredMixin):
    """Regra de visibilidade usada por todas as views de chamado:
    administrador enxerga todos; usuário comum enxerga só os seus."""

    def get_queryset_visivel(self):
        qs = Chamado.objects.select_related('usuario')
        if self.request.user.eh_admin:
            return qs
        return qs.filter(usuario=self.request.user)


class ChamadoListView(ChamadoBaseMixin, ListView):
    """Relatório de chamados (já ordenado por data, do mais recente ao mais antigo)."""

    template_name = 'tickets/lista_de_chamados.html'
    context_object_name = 'chamados'

    def get_queryset(self):
        return self.get_queryset_visivel()


class ChamadoCreateView(ChamadoBaseMixin, View):
    """Abertura de chamado (recebe o POST do modal 'Novo chamado')."""

    def get(self, request):
        return redirect('ticket_list')

    def post(self, request):
        form = ChamadoForm(request.POST)
        if form.is_valid():
            chamado = form.save(commit=False)
            chamado.usuario = request.user   # quem está logado
            chamado.save()                   # data e status "aberto" vêm do model
            messages.success(request, f'Chamado #{chamado.pk} aberto com sucesso.')
        else:
            messages.error(request, 'Não foi possível abrir o chamado. Confira os campos.')
        return redirect('ticket_list')


class ChamadoStatusView(AdminRequiredMixin, View):
    """Altera o status do chamado (somente administrador)."""

    STATUS_PERMITIDOS = {Chamado.ANDAMENTO, Chamado.FINALIZADO}

    def get(self, request):
        return redirect('ticket_list')

    def post(self, request):
        chamado = get_object_or_404(Chamado, pk=request.POST.get('chamado_id') or 0)
        novo_status = request.POST.get('status')
        if novo_status not in self.STATUS_PERMITIDOS:
            messages.error(request, 'Status inválido.')
        else:
            chamado.status = novo_status
            chamado.save(update_fields=['status'])
            messages.success(
                request,
                f'Chamado #{chamado.pk} agora está "{chamado.get_status_display()}".',
            )
        return redirect('ticket_list')


class ChamadoCancelView(ChamadoBaseMixin, View):
    """Cancela (exclui) um chamado que ainda não teve tratativa iniciada."""

    def get(self, request):
        return redirect('ticket_list')

    def post(self, request):
        # Comum só alcança os próprios chamados; admin alcança todos.
        chamado = get_object_or_404(
            self.get_queryset_visivel(), pk=request.POST.get('chamado_id') or 0
        )
        if not chamado.pode_cancelar:
            messages.error(
                request,
                'Este chamado já está em tratativa e não pode mais ser cancelado.',
            )
        else:
            numero = chamado.pk
            chamado.delete()
            messages.success(request, f'Chamado #{numero} cancelado e excluído.')
        return redirect('ticket_list')
