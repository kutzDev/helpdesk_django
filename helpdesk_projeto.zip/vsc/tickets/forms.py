from django import forms

from .models import Chamado


class ChamadoForm(forms.ModelForm):
    """Formulário de abertura de chamado.

    Só expõe os 3 campos que o usuário digita. Usuário, data e status são
    definidos pelo servidor, então não dá para forjá-los pelo navegador.
    """

    class Meta:
        model = Chamado
        fields = ['titulo', 'subtitulo', 'descricao']
