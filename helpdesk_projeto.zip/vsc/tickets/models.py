from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class Usuario(AbstractUser):
    """Usuário do sistema.

    Estende o usuário padrão do Django (que já cuida de login, senha com hash,
    sessão etc.) e acrescenta o campo `permissao`:
        0 -> usuário comum
        1 -> administrador
    """

    COMUM = 0
    ADMINISTRADOR = 1
    PERMISSOES = [
        (COMUM, 'Usuário comum'),
        (ADMINISTRADOR, 'Administrador'),
    ]

    permissao = models.PositiveSmallIntegerField(
        'permissão', choices=PERMISSOES, default=COMUM
    )

    @property
    def eh_admin(self):
        # is_superuser entra na conta para o caso de o admin ser criado com
        # `createsuperuser` (que não conhece o campo `permissao`).
        return self.permissao == self.ADMINISTRADOR or self.is_superuser

    @property
    def nome_exibicao(self):
        return self.get_full_name() or self.username

    def __str__(self):
        return self.nome_exibicao


class Chamado(models.Model):
    """Solicitação de reparo aberta por um usuário."""

    ABERTO = 'aberto'
    ANDAMENTO = 'andamento'
    FINALIZADO = 'finalizado'
    STATUS = [
        (ABERTO, 'Em aberto'),
        (ANDAMENTO, 'Em andamento'),
        (FINALIZADO, 'Finalizado'),
    ]

    # O id (chave primária) é criado automaticamente pelo Django.
    usuario = models.ForeignKey(
        Usuario, on_delete=models.CASCADE, related_name='chamados'
    )
    titulo = models.CharField('título', max_length=80)
    subtitulo = models.CharField('subtítulo', max_length=120)
    descricao = models.TextField('descrição', max_length=500)
    data = models.DateField(default=timezone.localdate, editable=False)
    status = models.CharField(
        max_length=10, choices=STATUS, default=ABERTO, editable=False
    )

    class Meta:
        # Do mais recente para o mais antigo (exigência do trabalho).
        ordering = ['-data', '-id']

    @property
    def pode_cancelar(self):
        """Só chamados ainda sem tratativa (Em aberto) podem ser cancelados."""
        return self.status == self.ABERTO

    def __str__(self):
        return f'#{self.pk} {self.titulo}'
