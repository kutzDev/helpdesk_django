from django.core.management.base import BaseCommand

from tickets.models import Chamado, Usuario


class Command(BaseCommand):
    help = 'Cria o administrador e o usuário comum iniciais (e, com --demo, chamados de exemplo).'

    def add_arguments(self, parser):
        parser.add_argument('--demo', action='store_true',
                            help='Também cria alguns chamados de exemplo.')

    def handle(self, *args, **opts):
        admin, _ = self._garantir('admin', 'admin123', 'Ana Gomes', Usuario.ADMINISTRADOR)
        comum, _ = self._garantir('usuario', 'usuario123', 'João Silva', Usuario.COMUM)

        if opts['demo'] and not Chamado.objects.exists():
            Chamado.objects.create(usuario=comum, titulo='Impressora não imprime',
                                   subtitulo='Impressora do 2º andar',
                                   descricao='Não puxa o papel e acende a luz vermelha.')
            c2 = Chamado.objects.create(usuario=comum, titulo='Computador desliga sozinho',
                                        subtitulo='PC da recepção',
                                        descricao='Desliga depois de alguns minutos de uso.')
            c2.status = Chamado.ANDAMENTO
            c2.save(update_fields=['status'])
            c3 = Chamado.objects.create(usuario=admin, titulo='Monitor piscando',
                                        subtitulo='Sala de reunião',
                                        descricao='A tela pisca durante as apresentações.')
            c3.status = Chamado.FINALIZADO
            c3.save(update_fields=['status'])
            self.stdout.write(self.style.SUCCESS('Chamados de exemplo criados.'))

        self.stdout.write(self.style.SUCCESS(
            'Pronto!\n  admin   / admin123   (permissão 1)\n  usuario / usuario123 (permissão 0)'))

    def _garantir(self, username, senha, nome, permissao):
        user, criado = Usuario.objects.get_or_create(username=username)
        if criado:
            user.first_name = nome
            user.permissao = permissao
            user.is_staff = permissao == Usuario.ADMINISTRADOR   # entra em /admin/
            user.is_superuser = permissao == Usuario.ADMINISTRADOR
            user.set_password(senha)                              # grava com hash
            user.save()
        return user, criado
