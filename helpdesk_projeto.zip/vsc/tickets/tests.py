from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Chamado, Usuario


class BaseTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin = Usuario.objects.create_user('admin', password='x', permissao=Usuario.ADMINISTRADOR)
        cls.ana = Usuario.objects.create_user('ana', password='x')     # comum
        cls.bia = Usuario.objects.create_user('bia', password='x')     # comum

    def novo(self, usuario, titulo='Teste', status=Chamado.ABERTO):
        c = Chamado.objects.create(usuario=usuario, titulo=titulo, subtitulo='sub', descricao='desc')
        if status != Chamado.ABERTO:
            c.status = status
            c.save(update_fields=['status'])
        return c


class LoginTests(BaseTestCase):
    def test_lista_exige_login(self):
        r = self.client.get(reverse('ticket_list'))
        self.assertRedirects(r, f"{reverse('login')}?next={reverse('ticket_list')}")

    def test_login_correto_e_senha_errada(self):
        r = self.client.post(reverse('login'), {'username': 'ana', 'password': 'x'})
        self.assertRedirects(r, reverse('ticket_list'))
        self.client.logout()
        r = self.client.post(reverse('login'), {'username': 'ana', 'password': 'errada'})
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, 'incorretos')

    def test_logout(self):
        self.client.force_login(self.ana)
        self.client.post(reverse('logout'))
        r = self.client.get(reverse('ticket_list'))
        self.assertEqual(r.status_code, 302)


class PermissaoModelTests(BaseTestCase):
    def test_eh_admin(self):
        self.assertTrue(self.admin.eh_admin)
        self.assertFalse(self.ana.eh_admin)

    def test_superuser_conta_como_admin(self):
        su = Usuario.objects.create_superuser('root', password='x')   # permissao fica 0
        self.assertTrue(su.eh_admin)


class ListagemTests(BaseTestCase):
    def test_comum_ve_so_os_seus(self):
        self.novo(self.ana, 'da Ana')
        self.novo(self.bia, 'da Bia')
        self.client.force_login(self.ana)
        r = self.client.get(reverse('ticket_list'))
        self.assertEqual([c.titulo for c in r.context['chamados']], ['da Ana'])

    def test_admin_ve_todos(self):
        self.novo(self.ana)
        self.novo(self.bia)
        self.client.force_login(self.admin)
        r = self.client.get(reverse('ticket_list'))
        self.assertEqual(len(r.context['chamados']), 2)

    def test_ordenado_do_mais_recente_para_o_mais_antigo(self):
        antigo = self.novo(self.ana, 'antigo')
        Chamado.objects.filter(pk=antigo.pk).update(data=timezone.localdate() - timezone.timedelta(days=5))
        self.novo(self.ana, 'novo')
        self.client.force_login(self.ana)
        r = self.client.get(reverse('ticket_list'))
        self.assertEqual([c.titulo for c in r.context['chamados']], ['novo', 'antigo'])

    def test_botoes_de_admin_so_aparecem_para_admin(self):
        self.novo(self.ana)
        self.client.force_login(self.ana)
        self.assertNotContains(self.client.get(reverse('ticket_list')), 'Alterar status')
        self.client.force_login(self.admin)
        self.assertContains(self.client.get(reverse('ticket_list')), 'Alterar status')


class CriacaoTests(BaseTestCase):
    def test_cria_com_usuario_data_e_status_automaticos(self):
        self.client.force_login(self.ana)
        r = self.client.post(reverse('ticket_create'), {
            'titulo': 'Impressora', 'subtitulo': '2º andar', 'descricao': 'Não imprime',
        })
        self.assertRedirects(r, reverse('ticket_list'))
        c = Chamado.objects.get()
        self.assertEqual(c.usuario, self.ana)
        self.assertEqual(c.status, Chamado.ABERTO)
        self.assertEqual(c.data, timezone.localdate())

    def test_ignora_campos_forjados(self):
        self.client.force_login(self.ana)
        self.client.post(reverse('ticket_create'), {
            'titulo': 'x', 'subtitulo': 'y', 'descricao': 'z',
            'status': 'finalizado', 'usuario': self.bia.pk, 'data': '2000-01-01',
        })
        c = Chamado.objects.get()
        self.assertEqual((c.status, c.usuario, c.data), (Chamado.ABERTO, self.ana, timezone.localdate()))

    def test_campos_obrigatorios(self):
        self.client.force_login(self.ana)
        self.client.post(reverse('ticket_create'), {'titulo': '', 'subtitulo': 'y', 'descricao': 'z'})
        self.assertEqual(Chamado.objects.count(), 0)


class StatusTests(BaseTestCase):
    def test_admin_altera_status(self):
        c = self.novo(self.ana)
        self.client.force_login(self.admin)
        self.client.post(reverse('ticket_status'), {'chamado_id': c.pk, 'status': 'andamento'})
        c.refresh_from_db()
        self.assertEqual(c.status, Chamado.ANDAMENTO)
        self.client.post(reverse('ticket_status'), {'chamado_id': c.pk, 'status': 'finalizado'})
        c.refresh_from_db()
        self.assertEqual(c.status, Chamado.FINALIZADO)

    def test_comum_nao_altera_status(self):
        c = self.novo(self.ana)
        self.client.force_login(self.ana)
        r = self.client.post(reverse('ticket_status'), {'chamado_id': c.pk, 'status': 'finalizado'})
        self.assertEqual(r.status_code, 403)
        c.refresh_from_db()
        self.assertEqual(c.status, Chamado.ABERTO)

    def test_status_invalido_e_rejeitado(self):
        c = self.novo(self.ana)
        self.client.force_login(self.admin)
        self.client.post(reverse('ticket_status'), {'chamado_id': c.pk, 'status': 'aberto'})
        self.client.post(reverse('ticket_status'), {'chamado_id': c.pk, 'status': 'banana'})
        c.refresh_from_db()
        self.assertEqual(c.status, Chamado.ABERTO)


class CancelamentoTests(BaseTestCase):
    def test_cancela_chamado_em_aberto_e_exclui(self):
        c = self.novo(self.ana)
        self.client.force_login(self.ana)
        self.client.post(reverse('ticket_cancel'), {'chamado_id': c.pk})
        self.assertFalse(Chamado.objects.filter(pk=c.pk).exists())

    def test_nao_cancela_com_tratativa_iniciada(self):
        for st in (Chamado.ANDAMENTO, Chamado.FINALIZADO):
            c = self.novo(self.ana, status=st)
            self.client.force_login(self.ana)
            self.client.post(reverse('ticket_cancel'), {'chamado_id': c.pk})
            self.assertTrue(Chamado.objects.filter(pk=c.pk).exists())

    def test_comum_nao_cancela_chamado_de_outro(self):
        c = self.novo(self.bia)
        self.client.force_login(self.ana)
        r = self.client.post(reverse('ticket_cancel'), {'chamado_id': c.pk})
        self.assertEqual(r.status_code, 404)
        self.assertTrue(Chamado.objects.filter(pk=c.pk).exists())

    def test_admin_cancela_chamado_em_aberto_de_qualquer_um(self):
        c = self.novo(self.bia)
        self.client.force_login(self.admin)
        self.client.post(reverse('ticket_cancel'), {'chamado_id': c.pk})
        self.assertFalse(Chamado.objects.filter(pk=c.pk).exists())
