from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Chamado, Mensagem, Setor, Usuario


class BaseTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin = Usuario.objects.create_user(
            'admin', password='x', permissao=Usuario.ADMINISTRADOR, setor=Setor.SUPER)
        cls.matheus = Usuario.objects.create_user('matheus', password='x', setor=Setor.GERENCIA)
        cls.henrique = Usuario.objects.create_user('henrique', password='x', setor=Setor.INFORMATICA)
        cls.kaua = Usuario.objects.create_user('kaua', password='x', setor=Setor.INFORMATICA)
        cls.nelma = Usuario.objects.create_user('nelma', password='x', setor=Setor.CONTABILIDADE)

    def novo(self, usuario, setor=Setor.INFORMATICA, titulo='Teste', status=Chamado.ABERTO):
        c = Chamado.objects.create(usuario=usuario, setor_destino=setor,
                                   titulo=titulo, subtitulo='sub', descricao='desc')
        if status != Chamado.ABERTO:
            c.status = status
            c.save(update_fields=['status'])
        return c

    def lista(self, usuario):
        self.client.force_login(usuario)
        return self.client.get(reverse('ticket_list')).context['chamados']


class LoginTests(BaseTestCase):
    def test_lista_exige_login(self):
        r = self.client.get(reverse('ticket_list'))
        self.assertRedirects(r, f"{reverse('login')}?next={reverse('ticket_list')}")

    def test_login_correto_e_senha_errada(self):
        r = self.client.post(reverse('login'), {'username': 'nelma', 'password': 'x'})
        self.assertRedirects(r, reverse('ticket_list'))
        self.client.logout()
        r = self.client.post(reverse('login'), {'username': 'nelma', 'password': 'errada'})
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, 'incorretos')

    def test_logout(self):
        self.client.force_login(self.nelma)
        self.client.post(reverse('logout'))
        self.assertEqual(self.client.get(reverse('ticket_list')).status_code, 302)

    def test_login_tem_botao_de_tema(self):
        self.assertContains(self.client.get(reverse('login')), 'data-tema-toggle')


class PermissaoModelTests(BaseTestCase):
    def test_eh_admin(self):
        self.assertTrue(self.admin.eh_admin)
        self.assertFalse(self.nelma.eh_admin)

    def test_superuser_conta_como_super_usuario(self):
        su = Usuario.objects.create_superuser('root', password='x')
        self.assertTrue(su.eh_admin)
        self.assertEqual(su.setor_efetivo, Setor.SUPER)


class VisibilidadeTests(BaseTestCase):
    def test_setor_ve_so_o_que_foi_enviado_a_ele(self):
        self.novo(self.matheus, Setor.INFORMATICA, 'para TI')
        self.novo(self.matheus, Setor.CONTABILIDADE, 'para contabilidade')
        self.assertEqual([c.titulo for c in self.lista(self.henrique)], ['para TI'])
        self.assertEqual([c.titulo for c in self.lista(self.kaua)], ['para TI'])
        self.assertEqual([c.titulo for c in self.lista(self.nelma)], ['para contabilidade'])

    def test_quem_abriu_ve_os_seus(self):
        self.novo(self.matheus, Setor.INFORMATICA, 'a')
        self.novo(self.matheus, Setor.CONTABILIDADE, 'b')
        self.novo(self.nelma, Setor.INFORMATICA, 'de outra pessoa')
        self.assertEqual(sorted(c.titulo for c in self.lista(self.matheus)), ['a', 'b'])

    def test_admin_ve_todos(self):
        self.novo(self.matheus, Setor.INFORMATICA)
        self.novo(self.nelma, Setor.DONO)
        self.novo(self.kaua, Setor.GERENCIA)
        self.assertEqual(len(self.lista(self.admin)), 3)

    def test_chamado_para_super_usuario_so_admin_ve(self):
        self.novo(self.matheus, Setor.SUPER, 'para admin')
        self.assertEqual(len(self.lista(self.henrique)), 0)
        self.assertEqual(len(self.lista(self.admin)), 1)

    def test_detalhe_de_chamado_alheio_da_404(self):
        c = self.novo(self.matheus, Setor.INFORMATICA)
        self.client.force_login(self.nelma)
        self.assertEqual(self.client.get(reverse('ticket_detail', args=[c.pk])).status_code, 404)

    def test_ordenado_do_mais_recente_para_o_mais_antigo(self):
        antigo = self.novo(self.matheus, titulo='antigo')
        Chamado.objects.filter(pk=antigo.pk).update(data=timezone.localdate() - timezone.timedelta(days=5))
        self.novo(self.matheus, titulo='novo')
        self.assertEqual([c.titulo for c in self.lista(self.matheus)], ['novo', 'antigo'])


class FiltroTests(BaseTestCase):
    def test_marca_meus_e_pendentes(self):
        meu = self.novo(self.henrique, Setor.CONTABILIDADE, 'meu')
        recebido = self.novo(self.matheus, Setor.INFORMATICA, 'recebido')
        chamados = {c.titulo: c for c in self.lista(self.henrique)}
        self.assertTrue(chamados['meu'].eh_meu)
        self.assertFalse(chamados['meu'].pendente)          # ninguém respondeu ainda
        self.assertFalse(chamados['recebido'].eh_meu)
        self.assertTrue(chamados['recebido'].pendente)      # setor precisa responder

        Mensagem.objects.create(chamado=meu, autor=self.nelma, texto='oi')
        Mensagem.objects.create(chamado=recebido, autor=self.kaua, texto='já vou')
        chamados = {c.titulo: c for c in self.lista(self.henrique)}
        self.assertTrue(chamados['meu'].pendente)           # contabilidade respondeu
        self.assertFalse(chamados['recebido'].pendente)     # colega de setor já respondeu

    def test_finalizado_nunca_fica_pendente(self):
        self.novo(self.matheus, Setor.INFORMATICA, status=Chamado.FINALIZADO)
        self.assertFalse(self.lista(self.henrique)[0].pendente)


class CriacaoTests(BaseTestCase):
    def test_cria_com_setor_usuario_data_e_status(self):
        self.client.force_login(self.matheus)
        r = self.client.post(reverse('ticket_create'), {
            'setor_destino': 'contabilidade', 'titulo': 'NF', 'subtitulo': 'out', 'descricao': 'x',
        })
        self.assertRedirects(r, reverse('ticket_list'))
        c = Chamado.objects.get()
        self.assertEqual((c.usuario, c.setor_destino, c.status, c.data),
                         (self.matheus, Setor.CONTABILIDADE, Chamado.ABERTO, timezone.localdate()))

    def test_ignora_campos_forjados(self):
        self.client.force_login(self.matheus)
        self.client.post(reverse('ticket_create'), {
            'setor_destino': 'informatica', 'titulo': 'x', 'subtitulo': 'y', 'descricao': 'z',
            'status': 'finalizado', 'usuario': self.nelma.pk, 'data': '2000-01-01',
        })
        c = Chamado.objects.get()
        self.assertEqual((c.status, c.usuario, c.data), (Chamado.ABERTO, self.matheus, timezone.localdate()))

    def test_setor_obrigatorio_e_valido(self):
        self.client.force_login(self.matheus)
        base = {'titulo': 'x', 'subtitulo': 'y', 'descricao': 'z'}
        self.client.post(reverse('ticket_create'), base)
        self.client.post(reverse('ticket_create'), {**base, 'setor_destino': 'banana'})
        self.assertEqual(Chamado.objects.count(), 0)

    def test_campos_obrigatorios(self):
        self.client.force_login(self.matheus)
        self.client.post(reverse('ticket_create'),
                         {'setor_destino': 'dono', 'titulo': '', 'subtitulo': 'y', 'descricao': 'z'})
        self.assertEqual(Chamado.objects.count(), 0)


class ChatTests(BaseTestCase):
    def test_quem_abriu_e_o_setor_respondem(self):
        c = self.novo(self.matheus, Setor.INFORMATICA)
        self.client.force_login(self.henrique)
        self.client.post(reverse('ticket_reply', args=[c.pk]), {'texto': 'Vou ver'})
        self.client.force_login(self.matheus)
        self.client.post(reverse('ticket_reply', args=[c.pk]), {'texto': 'Obrigado'})
        self.assertEqual(list(c.mensagens.values_list('autor__username', 'texto')),
                         [('henrique', 'Vou ver'), ('matheus', 'Obrigado')])

    def test_pode_responder_mesmo_finalizado(self):
        c = self.novo(self.matheus, Setor.INFORMATICA, status=Chamado.FINALIZADO)
        self.client.force_login(self.matheus)
        self.client.post(reverse('ticket_reply', args=[c.pk]), {'texto': 'Voltou a dar problema'})
        self.assertEqual(c.mensagens.count(), 1)

    def test_outro_setor_nao_responde(self):
        c = self.novo(self.matheus, Setor.INFORMATICA)
        self.client.force_login(self.nelma)
        r = self.client.post(reverse('ticket_reply', args=[c.pk]), {'texto': 'intrusa'})
        self.assertEqual(r.status_code, 404)
        self.assertEqual(c.mensagens.count(), 0)

    def test_mensagem_vazia_nao_grava(self):
        c = self.novo(self.matheus)
        self.client.force_login(self.matheus)
        self.client.post(reverse('ticket_reply', args=[c.pk]), {'texto': ''})
        self.assertEqual(c.mensagens.count(), 0)

    def test_pagina_mostra_conversa(self):
        c = self.novo(self.matheus)
        Mensagem.objects.create(chamado=c, autor=self.kaua, texto='Reiniciei o roteador')
        self.client.force_login(self.matheus)
        self.assertContains(self.client.get(reverse('ticket_detail', args=[c.pk])), 'Reiniciei o roteador')


class StatusTests(BaseTestCase):
    def test_setor_de_destino_altera_status(self):
        c = self.novo(self.matheus, Setor.INFORMATICA)
        self.client.force_login(self.kaua)
        self.client.post(reverse('ticket_status'), {'chamado_id': c.pk, 'status': 'andamento'})
        c.refresh_from_db()
        self.assertEqual(c.status, Chamado.ANDAMENTO)

    def test_admin_altera_status(self):
        c = self.novo(self.matheus, Setor.DONO)
        self.client.force_login(self.admin)
        self.client.post(reverse('ticket_status'), {'chamado_id': c.pk, 'status': 'finalizado'})
        c.refresh_from_db()
        self.assertEqual(c.status, Chamado.FINALIZADO)

    def test_quem_abriu_nao_altera_status(self):
        c = self.novo(self.matheus, Setor.INFORMATICA)
        self.client.force_login(self.matheus)
        r = self.client.post(reverse('ticket_status'), {'chamado_id': c.pk, 'status': 'finalizado'})
        self.assertEqual(r.status_code, 403)
        c.refresh_from_db()
        self.assertEqual(c.status, Chamado.ABERTO)

    def test_status_invalido_e_rejeitado(self):
        c = self.novo(self.matheus)
        self.client.force_login(self.admin)
        self.client.post(reverse('ticket_status'), {'chamado_id': c.pk, 'status': 'aberto'})
        self.client.post(reverse('ticket_status'), {'chamado_id': c.pk, 'status': 'banana'})
        c.refresh_from_db()
        self.assertEqual(c.status, Chamado.ABERTO)


class CancelamentoTests(BaseTestCase):
    def test_cancela_e_apaga_o_chat_junto(self):
        c = self.novo(self.matheus)
        Mensagem.objects.create(chamado=c, autor=self.henrique, texto='oi')
        self.client.force_login(self.matheus)
        self.client.post(reverse('ticket_cancel'), {'chamado_id': c.pk})
        self.assertFalse(Chamado.objects.filter(pk=c.pk).exists())
        self.assertEqual(Mensagem.objects.count(), 0)

    def test_nao_cancela_com_tratativa_iniciada(self):
        for st in (Chamado.ANDAMENTO, Chamado.FINALIZADO):
            c = self.novo(self.matheus, status=st)
            self.client.force_login(self.matheus)
            self.client.post(reverse('ticket_cancel'), {'chamado_id': c.pk})
            self.assertTrue(Chamado.objects.filter(pk=c.pk).exists())

    def test_setor_de_destino_nao_cancela(self):
        c = self.novo(self.matheus, Setor.INFORMATICA)
        self.client.force_login(self.henrique)
        r = self.client.post(reverse('ticket_cancel'), {'chamado_id': c.pk})
        self.assertEqual(r.status_code, 403)
        self.assertTrue(Chamado.objects.filter(pk=c.pk).exists())

    def test_outro_setor_nao_cancela(self):
        c = self.novo(self.matheus, Setor.INFORMATICA)
        self.client.force_login(self.nelma)
        r = self.client.post(reverse('ticket_cancel'), {'chamado_id': c.pk})
        self.assertEqual(r.status_code, 404)

    def test_admin_cancela_chamado_em_aberto_de_qualquer_um(self):
        c = self.novo(self.nelma, Setor.DONO)
        self.client.force_login(self.admin)
        self.client.post(reverse('ticket_cancel'), {'chamado_id': c.pk})
        self.assertFalse(Chamado.objects.filter(pk=c.pk).exists())


class ComandoUsuariosTests(TestCase):
    def test_cria_os_7_usuarios_com_senhas_diferentes(self):
        import io
        import tempfile
        from pathlib import Path

        from django.core.management import call_command

        Usuario.objects.create_user('usuario', password='x')   # antigo: deve sumir
        with tempfile.TemporaryDirectory() as d:
            saida = Path(d) / 'acessos.md'
            call_command('criar_usuarios_iniciais', saida=str(saida), stdout=io.StringIO())
            doc = saida.read_text(encoding='utf-8')

        nomes = ['nelma', 'matheus', 'bruno', 'viviane', 'henrique', 'kaua', 'admin']
        self.assertEqual(sorted(Usuario.objects.values_list('username', flat=True)), sorted(nomes))
        senhas = [linha.split('`')[3] for linha in doc.splitlines() if linha.startswith('| ') and '`' in linha]
        self.assertEqual(len(senhas), 7)
        self.assertEqual(len(set(senhas)), 7)
        for nome, senha in zip(nomes, senhas):
            self.assertTrue(Usuario.objects.get(username=nome).check_password(senha))
        self.assertTrue(Usuario.objects.get(username='admin').eh_admin)
        self.assertEqual(Usuario.objects.get(username='viviane').setor, Setor.DONO)
