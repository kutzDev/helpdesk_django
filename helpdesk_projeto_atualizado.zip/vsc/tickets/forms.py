from django import forms

from .models import Chamado, Mensagem


class ChamadoForm(forms.ModelForm):
    """Formulário de abertura de chamado.

    Só expõe os campos que o usuário escolhe ou digita. Usuário, data e status
    são definidos pelo servidor, então não dá para forjá-los pelo navegador.
    """

    class Meta:
        model = Chamado
        fields = ['setor_destino', 'titulo', 'subtitulo', 'descricao']


class MensagemForm(forms.ModelForm):
    """Resposta no chat de um chamado."""

    class Meta:
        model = Mensagem
        fields = ['texto']
