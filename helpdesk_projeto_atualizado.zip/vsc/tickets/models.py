from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class Setor(models.TextChoices):
    """Setores da empresa. Cada usuário pertence a um setor e cada chamado é
    enviado para um setor. Quem é do setor de destino enxerga o chamado."""

    DONO = 'dono', 'Dono'
    GERENCIA = 'gerencia', 'Gerência'
    INFORMATICA = 'informatica', 'Informática'
    CONTABILIDADE = 'contabilidade', 'Contabilidade'
    SUPER = 'super', 'Super Usuário'


class Usuario(AbstractUser):
    """Usuário do sistema.

    Estende o usuário padrão do Django (que já cuida de login, senha com hash,
    sessão etc.) e acrescenta:
        permissao -> 0 usuário comum, 1 administrador (Super Usuário)
        setor     -> setor da empresa ao qual a pessoa pertence
    """

    COMUM = 0
    ADMINISTRADOR = 1
    PERMISSOES = [
        (COMUM, 'Usuário comum'),
        (ADMINISTRADOR, 'Administrador'),
    ]

    permissao = models.PositiveSmallIntegerField(
        'permissão', choices=PERMISSOES, default=COMUM
    )
    setor = models.CharField(
        max_length=15, choices=Setor.choices, blank=True, default=''
    )

    @property
    def eh_admin(self):
        # is_superuser entra na conta para o caso de o admin ser criado com
        # `createsuperuser` (que não conhece o campo `permissao`).
        return self.permissao == self.ADMINISTRADOR or self.is_superuser

    @property
    def setor_efetivo(self):
        """Setor usado nas regras. O administrador sempre conta como Super Usuário."""
        return Setor.SUPER if self.eh_admin else self.setor

    @property
    def nome_exibicao(self):
        return self.get_full_name() or self.username

    def __str__(self):
        return self.nome_exibicao


class Chamado(models.Model):
    """Solicitação aberta por um usuário para um setor."""

    ABERTO = 'aberto'
    ANDAMENTO = 'andamento'
    FINALIZADO = 'finalizado'
    STATUS = [
        (ABERTO, 'Em aberto'),
        (ANDAMENTO, 'Em andamento'),
        (FINALIZADO, 'Finalizado'),
    ]

    # O id (chave primária) é criado automaticamente pelo Django.
    usuario = models.ForeignKey(
        Usuario, on_delete=models.CASCADE, related_name='chamados'
    )
    setor_destino = models.CharField(
        'enviar para', max_length=15, choices=Setor.choices, default=Setor.INFORMATICA
    )
    titulo = models.CharField('título', max_length=80)
    subtitulo = models.CharField('subtítulo', max_length=120)
    descricao = models.TextField('descrição', max_length=500)
    data = models.DateField(default=timezone.localdate, editable=False)
    status = models.CharField(
        max_length=10, choices=STATUS, default=ABERTO, editable=False
    )

    class Meta:
        # Do mais recente para o mais antigo (exigência do trabalho).
        ordering = ['-data', '-id']

    @property
    def pode_cancelar(self):
        """Só chamados ainda sem tratativa (Em aberto) podem ser cancelados."""
        return self.status == self.ABERTO

    def eh_do_setor(self, usuario):
        """True se o usuário está do lado de quem recebe o chamado."""
        return usuario.setor_efetivo == self.setor_destino

    def pode_alterar_status(self, usuario):
        return usuario.eh_admin or self.eh_do_setor(usuario)

    def pode_excluir(self, usuario):
        return self.pode_cancelar and (usuario.eh_admin or usuario.pk == self.usuario_id)

    def resposta_pendente(self, usuario, ultimo_autor_id=None):
        """True quando a última fala do chamado foi do "outro lado" e cabe a
        este usuário responder.

        - Para quem abriu: pendente se a última mensagem é de outra pessoa.
        - Para quem é do setor de destino: pendente se a última fala é de quem
          abriu (inclui o chamado recém-aberto, ainda sem resposta).
        Chamados finalizados nunca ficam pendentes.
        """
        if self.status == self.FINALIZADO:
            return False
        if ultimo_autor_id is None:
            ultima = self.mensagens.order_by('-criado_em', '-id').first()
            ultimo_autor_id = ultima.autor_id if ultima else self.usuario_id
        if usuario.pk == self.usuario_id:
            return ultimo_autor_id != usuario.pk
        if self.eh_do_setor(usuario):
            return ultimo_autor_id == self.usuario_id
        return False

    def __str__(self):
        return f'#{self.pk} {self.titulo}'


class Mensagem(models.Model):
    """Resposta no chat de um chamado. É apagada junto com o chamado."""

    chamado = models.ForeignKey(
        Chamado, on_delete=models.CASCADE, related_name='mensagens'
    )
    autor = models.ForeignKey(
        Usuario, on_delete=models.CASCADE, related_name='mensagens'
    )
    texto = models.TextField(max_length=1000)
    criado_em = models.DateTimeField(default=timezone.now, editable=False)

    class Meta:
        ordering = ['criado_em', 'id']

    def __str__(self):
        return f'Mensagem de {self.autor} no chamado #{self.chamado_id}'
