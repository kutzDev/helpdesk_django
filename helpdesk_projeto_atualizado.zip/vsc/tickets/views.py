from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import PermissionDenied
from django.db.models import Count, OuterRef, Q, Subquery
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.views import View
from django.views.generic import DetailView, ListView

from .forms import ChamadoForm, MensagemForm
from .models import Chamado, Mensagem, Setor


class ChamadoBaseMixin(LoginRequiredMixin):
    """Regra de visibilidade usada por todas as views de chamado:
    - Super Usuário (administrador) enxerga todos;
    - os demais enxergam os chamados que abriram e os enviados ao seu setor."""

    def get_queryset_visivel(self):
        user = self.request.user
        qs = Chamado.objects.select_related('usuario')
        if user.eh_admin:
            return qs
        filtro = Q(usuario=user)
        if user.setor:
            filtro |= Q(setor_destino=user.setor)
        return qs.filter(filtro)


class ChamadoListView(ChamadoBaseMixin, ListView):
    """Relatório de chamados (já ordenado por data, do mais recente ao mais antigo)."""

    template_name = 'tickets/lista_de_chamados.html'
    context_object_name = 'chamados'

    def get_queryset(self):
        ultima = Mensagem.objects.filter(chamado=OuterRef('pk')).order_by('-criado_em', '-id')
        return self.get_queryset_visivel().annotate(
            ultimo_autor_id=Subquery(ultima.values('autor_id')[:1]),
            total_mensagens=Count('mensagens'),
        ).order_by('-data', '-id')   # com Count o Django ignora o Meta.ordering

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        user = self.request.user
        for c in ctx['chamados']:
            c.eh_meu = c.usuario_id == user.pk
            c.pendente = c.resposta_pendente(user, c.ultimo_autor_id or c.usuario_id)
        ctx['form_setores'] = Setor.choices
        return ctx


class ChamadoDetailView(ChamadoBaseMixin, DetailView):
    """Página do chamado com o chat de respostas."""

    template_name = 'tickets/chamado.html'
    context_object_name = 'chamado'

    def get_queryset(self):
        return self.get_queryset_visivel()

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        user = self.request.user
        chamado = self.object
        ctx['mensagens'] = chamado.mensagens.select_related('autor')
        ctx['pode_alterar_status'] = chamado.pode_alterar_status(user)
        ctx['pode_excluir'] = chamado.pode_excluir(user)
        return ctx


class ChamadoCreateView(ChamadoBaseMixin, View):
    """Abertura de chamado (recebe o POST do modal 'Novo chamado')."""

    def get(self, request):
        return redirect('ticket_list')

    def post(self, request):
        form = ChamadoForm(request.POST)
        if form.is_valid():
            chamado = form.save(commit=False)
            chamado.usuario = request.user   # quem está logado
            chamado.save()                   # data e status "aberto" vêm do model
            messages.success(
                request,
                f'Chamado #{chamado.pk} enviado para {chamado.get_setor_destino_display()}.',
            )
        else:
            messages.error(request, 'Não foi possível abrir o chamado. Confira os campos.')
        return redirect('ticket_list')


class MensagemCreateView(ChamadoBaseMixin, View):
    """Resposta no chat do chamado. Qualquer pessoa que enxerga o chamado pode responder."""

    def get(self, request, pk):
        return redirect('ticket_detail', pk=pk)

    def post(self, request, pk):
        chamado = get_object_or_404(self.get_queryset_visivel(), pk=pk)
        form = MensagemForm(request.POST)
        if form.is_valid():
            mensagem = form.save(commit=False)
            mensagem.chamado = chamado
            mensagem.autor = request.user
            mensagem.save()
        else:
            messages.error(request, 'Escreva uma mensagem antes de enviar.')
        return redirect(reverse('ticket_detail', args=[pk]) + '#fim')


class ChamadoStatusView(ChamadoBaseMixin, View):
    """Altera o status do chamado (Super Usuário ou quem é do setor de destino)."""

    STATUS_PERMITIDOS = {Chamado.ANDAMENTO, Chamado.FINALIZADO}

    def get(self, request):
        return redirect('ticket_list')

    def post(self, request):
        chamado = get_object_or_404(
            self.get_queryset_visivel(), pk=request.POST.get('chamado_id') or 0
        )
        if not chamado.pode_alterar_status(request.user):
            raise PermissionDenied
        novo_status = request.POST.get('status')
        if novo_status not in self.STATUS_PERMITIDOS:
            messages.error(request, 'Status inválido.')
        else:
            chamado.status = novo_status
            chamado.save(update_fields=['status'])
            messages.success(
                request,
                f'Chamado #{chamado.pk} agora está "{chamado.get_status_display()}".',
            )
        return redirect('ticket_detail', pk=chamado.pk)


class ChamadoCancelView(ChamadoBaseMixin, View):
    """Cancela (exclui) um chamado que ainda não teve tratativa iniciada.
    Pode excluir: quem abriu o chamado ou o Super Usuário. O chat vai junto."""

    def get(self, request):
        return redirect('ticket_list')

    def post(self, request):
        chamado = get_object_or_404(
            self.get_queryset_visivel(), pk=request.POST.get('chamado_id') or 0
        )
        if not (request.user.eh_admin or chamado.usuario_id == request.user.pk):
            raise PermissionDenied
        if not chamado.pode_cancelar:
            messages.error(
                request,
                'Este chamado já está em tratativa e não pode mais ser cancelado.',
            )
            return redirect('ticket_detail', pk=chamado.pk)
        numero = chamado.pk
        chamado.delete()
        messages.success(request, f'Chamado #{numero} cancelado e excluído.')
        return redirect('ticket_list')
