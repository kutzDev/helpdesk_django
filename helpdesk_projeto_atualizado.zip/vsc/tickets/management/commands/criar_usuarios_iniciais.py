import secrets
from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand
from django.utils import timezone

from tickets.models import Chamado, Mensagem, Setor, Usuario

# (usuário de login, nome exibido, setor, é Super Usuário?)
USUARIOS = [
    ('nelma', 'Nelma', Setor.CONTABILIDADE, False),
    ('matheus', 'Matheus', Setor.GERENCIA, False),
    ('bruno', 'Bruno', Setor.DONO, False),
    ('viviane', 'Viviane', Setor.DONO, False),
    ('henrique', 'Henrique', Setor.INFORMATICA, False),
    ('kaua', 'Kauã', Setor.INFORMATICA, False),
    ('admin', 'Admin', Setor.SUPER, True),
]

# Sem letras/números que se confundem (0/O, 1/l/I)
ALFABETO = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'


def gerar_senha(tamanho=10):
    return ''.join(secrets.choice(ALFABETO) for _ in range(tamanho))


class Command(BaseCommand):
    help = ('Cria (ou reajusta) os usuários da empresa, gera uma senha nova e '
            'diferente para cada um e grava o documento ACESSOS_USUARIOS.md. '
            'Usuários fora da lista são removidos. Com --demo, cria chamados de exemplo.')

    def add_arguments(self, parser):
        parser.add_argument('--demo', action='store_true',
                            help='Também cria alguns chamados de exemplo.')
        parser.add_argument('--saida', default=str(Path(settings.BASE_DIR) / 'ACESSOS_USUARIOS.md'),
                            help='Onde gravar o documento de acessos.')

    def handle(self, *args, **opts):
        acessos = []
        for username, nome, setor, super_usuario in USUARIOS:
            user, _ = Usuario.objects.get_or_create(username=username)
            senha = gerar_senha()
            user.first_name = nome
            user.last_name = ''
            user.setor = setor
            user.permissao = Usuario.ADMINISTRADOR if super_usuario else Usuario.COMUM
            user.is_staff = super_usuario          # entra em /admin/
            user.is_superuser = super_usuario
            user.is_active = True
            user.set_password(senha)               # grava com hash
            user.save()
            acessos.append((nome, username, user.get_setor_display(), senha))

        removidos, _ = Usuario.objects.exclude(
            username__in=[u[0] for u in USUARIOS]).delete()
        if removidos:
            self.stdout.write(f'Usuários antigos removidos (com seus chamados): {removidos} registro(s).')

        if opts['demo'] and not Chamado.objects.exists():
            self._criar_demo()

        saida = Path(opts['saida'])
        saida.write_text(self._documento(acessos), encoding='utf-8')
        self.stdout.write(self.style.SUCCESS(f'Pronto! {len(acessos)} usuários. Acessos em: {saida}'))

    def _documento(self, acessos):
        linhas = [
            '# HelpDesk World Tennis: acessos dos usuários',
            '',
            f'Gerado em {timezone.localtime():%d/%m/%Y %H:%M}.',
            '',
            '> **Confidencial.** Entregue a cada pessoa somente a senha dela. '
            'Não envie este arquivo por grupo nem suba para o GitHub. '
            'Rodar `python manage.py criar_usuarios_iniciais` de novo troca todas as senhas.',
            '',
            '| Nome | Usuário (login) | Setor | Senha |',
            '|---|---|---|---|',
        ]
        linhas += [f'| {n} | `{u}` | {s} | `{p}` |' for n, u, s, p in acessos]
        linhas += [
            '',
            '## O que cada um vê',
            '',
            '- Cada pessoa vê os chamados que **abriu** e os chamados **enviados para o setor dela**.',
            '- **Admin (Super Usuário)** vê todos os chamados de todos os setores e entra também em `/admin/`.',
            '- Ao abrir um chamado, a pessoa escolhe o setor de destino: Dono, Gerência, '
            'Informática, Contabilidade ou Super Usuário.',
            '- Quem é do setor de destino (e o Admin) pode mudar o status. '
            'Quem abriu (e o Admin) pode cancelar enquanto estiver "Em aberto".',
            '',
            '## Cores dos setores',
            '',
            '| Setor | Cor |',
            '|---|---|',
            '| Dono | Cinza |',
            '| Informática | Azul |',
            '| Gerência | Verde |',
            '| Contabilidade | Laranja |',
            '| Super Usuário | Vermelho World Tennis |',
            '',
        ]
        return '\n'.join(linhas)

    def _criar_demo(self):
        u = {x.username: x for x in Usuario.objects.all()}
        c1 = Chamado.objects.create(
            usuario=u['matheus'], setor_destino=Setor.INFORMATICA,
            titulo='Impressora não imprime', subtitulo='Impressora da loja',
            descricao='Não puxa o papel e acende a luz vermelha.')
        Mensagem.objects.create(chamado=c1, autor=u['henrique'],
                                texto='Vou passar aí depois do almoço para olhar.')
        Chamado.objects.create(
            usuario=u['matheus'], setor_destino=Setor.CONTABILIDADE,
            titulo='Nota fiscal de outubro', subtitulo='Fornecedor de raquetes',
            descricao='Preciso da segunda via da nota do fornecedor.')
        c3 = Chamado.objects.create(
            usuario=u['nelma'], setor_destino=Setor.DONO,
            titulo='Aprovação de compra', subtitulo='Material de escritório',
            descricao='Orçamento em anexo no e-mail. Podem aprovar?')
        c3.status = Chamado.ANDAMENTO
        c3.save(update_fields=['status'])
        Chamado.objects.create(
            usuario=u['bruno'], setor_destino=Setor.GERENCIA,
            titulo='Escala de fim de ano', subtitulo='Equipe da loja',
            descricao='Montar a escala para dezembro.')
        self.stdout.write(self.style.SUCCESS('Chamados de exemplo criados.'))
