document.addEventListener("DOMContentLoaded", () => {
  const $  = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];

  const cards = $$(".ticket");

  /* ---------- Modal de criar chamado ---------- */
  $$("[data-open]").forEach(btn =>
    btn.addEventListener("click", () => document.getElementById(btn.dataset.open).showModal())
  );
  $$("dialog").forEach(dlg => {
    $$("[data-close]", dlg).forEach(b => b.addEventListener("click", () => dlg.close()));
    // clicar fora da caixa fecha
    dlg.addEventListener("click", e => { if (e.target === dlg) dlg.close(); });
  });

  // Data automática (só exibição). Quem grava a data de verdade é o back-end.
  const autoData = $("#auto-data");
  if (autoData) autoData.textContent = new Date().toLocaleDateString("pt-BR");

  const texto = $("textarea[name=descricao]"), contador = $("#contador");
  if (texto && contador) texto.addEventListener("input", () => (contador.textContent = texto.value.length));

  /* ---------- Filtros (assunto + status + data + busca) ---------- */
  const chipsAssunto = $$("[data-assunto]");
  const chipsStatus = $$("[data-status].chip");
  const fData = $("#filtro-data"), fBusca = $("#filtro-busca"), limpar = $("#limpar-filtros");
  const vazio = $("#vazio"), vazioTitulo = $("#vazio-titulo"), vazioTexto = $("#vazio-texto");
  let assuntoAtivo = "todos";
  let statusAtivo = "todos";

  const norm = s => (s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");

  const passaAssunto = card =>
    assuntoAtivo === "todos" ||
    (assuntoAtivo === "meus" && card.dataset.meu === "1") ||
    (assuntoAtivo === "pendentes" && card.dataset.pendente === "1");

  function contar() {
    const a = { todos: cards.length, meus: 0, pendentes: 0 };
    cards.forEach(card => {
      if (card.dataset.meu === "1") a.meus++;
      if (card.dataset.pendente === "1") a.pendentes++;
    });
    Object.entries(a).forEach(([k, v]) => { const el = $(`[data-count-assunto=${k}]`); if (el) el.textContent = v; });

    // Os números de status acompanham o assunto escolhido
    const s = { todos: 0, aberto: 0, andamento: 0, finalizado: 0 };
    cards.filter(passaAssunto).forEach(card => { s.todos++; s[card.dataset.status]++; });
    Object.entries(s).forEach(([k, v]) => { const el = $(`[data-count=${k}]`); if (el) el.textContent = v; });
  }

  function filtrar() {
    const data = fData ? fData.value : "";
    const busca = fBusca ? norm(fBusca.value.trim()) : "";
    let visiveis = 0;

    cards.forEach(card => {
      const ok =
        passaAssunto(card) &&
        (statusAtivo === "todos" || card.dataset.status === statusAtivo) &&
        (!data || card.dataset.date === data) &&
        (!busca || norm(card.dataset.busca).includes(busca));
      card.hidden = !ok;
      if (ok) visiveis++;
    });

    vazio.hidden = visiveis > 0;
    if (visiveis === 0) {
      if (cards.length === 0) {
        vazioTitulo.textContent = "Nenhum chamado por aqui";
        vazioTexto.textContent = "Quando você abrir um chamado, ele aparece nesta lista.";
      } else if (assuntoAtivo === "pendentes") {
        vazioTitulo.textContent = "Nenhuma resposta pendente";
        vazioTexto.textContent = "Você está em dia com os chamados.";
      } else {
        vazioTitulo.textContent = "Nada encontrado";
        vazioTexto.textContent = "Tente mudar ou limpar os filtros.";
      }
    }
  }

  chipsAssunto.forEach(chip => chip.addEventListener("click", () => {
    assuntoAtivo = chip.dataset.assunto;
    chipsAssunto.forEach(c => c.classList.toggle("is-active", c === chip));
    contar();
    filtrar();
  }));
  chipsStatus.forEach(chip => chip.addEventListener("click", () => {
    statusAtivo = chip.dataset.status;
    chipsStatus.forEach(c => c.classList.toggle("is-active", c === chip));
    filtrar();
  }));
  if (fData) fData.addEventListener("input", filtrar);
  if (fBusca) fBusca.addEventListener("input", filtrar);
  if (limpar) limpar.addEventListener("click", () => { fData.value = ""; fBusca.value = ""; filtrar(); });

  contar();
  filtrar();
});
