// Botão de tema claro/escuro. A escolha fica salva no navegador.
// (O tema inicial é aplicado por um script curto no <head> para não piscar.)
document.addEventListener("DOMContentLoaded", () => {
  const raiz = document.documentElement;
  document.querySelectorAll("[data-tema-toggle]").forEach(btn => {
    const rotular = () => {
      const escuro = raiz.dataset.theme === "dark";
      btn.setAttribute("aria-label", escuro ? "Mudar para o modo claro" : "Mudar para o modo escuro");
      btn.title = btn.getAttribute("aria-label");
    };
    rotular();
    btn.addEventListener("click", () => {
      raiz.dataset.theme = raiz.dataset.theme === "dark" ? "light" : "dark";
      try { localStorage.setItem("tema", raiz.dataset.theme); } catch (e) { /* navegador sem armazenamento */ }
      rotular();
    });
  });
});
