from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import Chamado, Mensagem, Usuario


@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    # Acrescenta "permissão" e "setor" à tela de edição e de criação de usuário.
    fieldsets = UserAdmin.fieldsets + (('HelpDesk', {'fields': ('permissao', 'setor')}),)
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('HelpDesk', {'fields': ('permissao', 'setor')}),
    )
    list_display = ('username', 'first_name', 'setor', 'permissao', 'is_active')
    list_filter = ('setor', 'permissao', 'is_active')


class MensagemInline(admin.TabularInline):
    model = Mensagem
    extra = 0
    readonly_fields = ('criado_em',)


@admin.register(Chamado)
class ChamadoAdmin(admin.ModelAdmin):
    list_display = ('id', 'titulo', 'usuario', 'setor_destino', 'data', 'status')
    list_filter = ('setor_destino', 'status', 'data')
    search_fields = ('titulo', 'subtitulo', 'usuario__username')
    readonly_fields = ('data',)
    inlines = [MensagemInline]
